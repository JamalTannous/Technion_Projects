package com.example.remotedogchipreader;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    Button login;
    TextView signup;
    EditText email,password;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);
        email = findViewById(R.id.userEmailLogin);
        password = findViewById(R.id.passwordLogin);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,signUpUser.class);
                startActivity(intent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean canRegister = checkDataEntered();
                if(canRegister){
                    email = findViewById(R.id.userEmailLogin);
                    password = findViewById(R.id.passwordLogin);
                    String emailText = email.getText().toString();
                    String passwordText = password.getText().toString();
                    DocumentReference docRef = db.collection("Users").document(emailText);
                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    ///// if password in true login and send chip reader id
                                    Map<String,Object> Data = document.getData();
                                    if(Data.get("password").toString().equals(passwordText)){
                                        String chipReaderID = Data.get("ChipReaderID").toString();
                                        Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                                        intent.putExtra("key",chipReaderID);
                                        startActivity(intent);
                                    }
                                    ////// account exist need to check password
                                    else{
                                        password.setError("Wrong Password !");
                                    }


                                } else {
                                    Toast.makeText(LoginActivity.this,"Account does not exist",Toast.LENGTH_LONG).show();
                                }
                            } else {
                                Log.d(TAG, "get failed with ", task.getException());
                            }
                        }
                    });

                }
            }
        });
    }
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    Boolean checkDataEntered() {
        Boolean canRegister = true;
        if (isEmail(email) == false) {
            email.setError("Enter valid email!");
            canRegister = false;
        }

        if (isEmpty(password)) {
            password.setError("You must enter a Password to login !");
            canRegister = false;
        }
        return canRegister;
    }
}