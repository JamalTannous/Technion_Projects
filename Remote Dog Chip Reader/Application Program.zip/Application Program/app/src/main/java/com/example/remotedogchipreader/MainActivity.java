package com.example.remotedogchipreader;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class MainActivity extends AppCompatActivity {
    FirebaseDatabase database;
    FirebaseFirestore tmp = FirebaseFirestore.getInstance();;
    DatabaseReference myRef;
    ImageView logo;
    Button scan;
    String chipReaderID = "-";
    int fromView = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        scan = (Button)findViewById(R.id.readScan);
        logo = findViewById(R.id.imageView2);
        database = FirebaseDatabase.getInstance();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            chipReaderID = extras.getString("key");
            fromView = extras.getInt("view");

        }
        myRef = database.getReference().child(chipReaderID);
        scan.setOnClickListener(view -> myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String dogID = snapshot.getValue().toString();
                    //// check if this key in database if not need to add it else view it
                    DocumentReference docRef = tmp.collection("Dogs").document(dogID);
                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {

                                    Intent intent = new Intent(MainActivity.this,ViewDogData.class);
                                    intent.putExtra("key",dogID);
                                    startActivity(intent);

                                } else {
                                    Intent intent = new Intent(MainActivity.this,SignUp.class);
                                    intent.putExtra("key",dogID);
                                    startActivity(intent);
                                }
                            } else {
                                Log.d(TAG, "get failed with ", task.getException());
                            }
                        }
                    });
                }else{
                        Intent intent = new Intent(MainActivity.this,ViewDogData.class);
                        intent.putExtra("key",chipReaderID);
                        startActivity(intent);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        }));

    }

}

