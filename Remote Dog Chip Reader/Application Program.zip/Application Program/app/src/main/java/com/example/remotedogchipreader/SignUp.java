package com.example.remotedogchipreader;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SignUp extends AppCompatActivity {
    ImageView dogPhoto;
    ImageButton addImage;
    EditText name,birthday,breed,color,ownerName,ownerCellphone;
    RadioGroup gender ;
    Button save;
    String value = "-";
    RadioButton radioButton;
    Bitmap imageBitmap;
    Boolean taken = false;
    //ImageButton addImage;
    int fromView = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageView dogPhoto;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            value = extras.getString("key");
            fromView = extras.getInt("view");
        }
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        name = findViewById(R.id.enterName);
        birthday = findViewById(R.id.bithday);
        breed = findViewById(R.id.breed);
        color = findViewById(R.id.colorInput);
        gender = findViewById(R.id.Gender);
        save = findViewById(R.id.edit);
        addImage = findViewById(R.id.addImage);
        ownerName = findViewById(R.id.ownerName);
        ownerCellphone = findViewById(R.id.ownerNumber);
        RadioGroup gender = findViewById(R.id.Gender);
        StorageReference sRef = firebaseStorage.getReference();
        dogPhoto = findViewById(R.id.DogPhoto);
        if(ContextCompat.checkSelfPermission(SignUp.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(SignUp.this,
                    new String[]{
                            Manifest.permission.CAMERA
                    },
                    100);
        }
        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);
            }
        });


        if(fromView == 1){
            DocumentReference docRef = db.collection("Dogs").document(value);
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Map<String,Object> dogData = document.getData();
                            name.setText(Objects.requireNonNull(dogData.get("Name")).toString());
                            birthday.setText(Objects.requireNonNull(dogData.get("Birthday")).toString());
                            breed.setText(Objects.requireNonNull(dogData.get("Breed")).toString());
                            color.setText(Objects.requireNonNull(dogData.get("Color")).toString());
                            ownerName.setText(Objects.requireNonNull(dogData.get("owner_name")).toString());
                            ownerCellphone.setText(Objects.requireNonNull(dogData.get("owner_cellPhone")).toString());
                            StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(value+".jpeg");
                            storageReference.getBytes(1024*1024).addOnCompleteListener(new OnCompleteListener<byte[]>() {
                                @Override
                                public void onComplete(@NonNull Task<byte[]> task) {
                                    Bitmap bitmap = BitmapFactory.decodeByteArray(task.getResult(),0, Objects.requireNonNull(task.getResult()).length);
                                    dogPhoto.setImageBitmap(bitmap);
                                }
                            });
                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
        }
        String finalValue = value;
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name = name.getText().toString();
                String Birthday = birthday.getText().toString();
                String Breed = breed.getText().toString();
                String Color = color.getText().toString();
                String owner_name = ownerName.getText().toString();
                String owner_cellPhone = ownerCellphone.getText().toString();
                String dogGender = "";
                int radioId = gender.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);
                dogGender = radioButton.getText().toString();
                Map<String,String> map = new HashMap<>();
                map.put("Name",Name);
                map.put("Birthday",Birthday);
                map.put("Breed",Breed);
                map.put("owner_name",owner_name);
                map.put("owner_cellPhone",owner_cellPhone);
                map.put("dogGender",dogGender);
                map.put("Color",Color);
                db.collection("Dogs").document(finalValue).set(map);
                if(taken){
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] data = baos.toByteArray();
                    StorageReference reference = firebaseStorage.getReference().child(value+".jpeg");
                    reference.putBytes(baos.toByteArray());

                }
                Intent intent = new Intent(SignUp.this,MainActivity.class);
                intent.putExtra("key",finalValue);
                startActivity(intent);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            imageBitmap = (Bitmap) extras.get("data");
            dogPhoto = findViewById(R.id.DogPhoto);
            dogPhoto.setImageBitmap(imageBitmap);
            taken = true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
    }

}