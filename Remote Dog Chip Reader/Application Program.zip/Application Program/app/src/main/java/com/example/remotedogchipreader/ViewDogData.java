package com.example.remotedogchipreader;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Map;
import java.util.Objects;

public class ViewDogData extends AppCompatActivity {
    TextView dogName,BD,breed,color,gender,ownerName,ownerCellPhone;
    FirebaseFirestore db;
    String value = "-";
    ImageView photo;
    Button edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_dog_data);
        dogName = findViewById(R.id.showName);
        BD = findViewById(R.id.showBD);
        breed = findViewById(R.id.BreedTV);
        color = findViewById(R.id.colorView);
        gender = findViewById(R.id.GenderView);
        ownerName = findViewById(R.id.nameOwner);
        ownerCellPhone = findViewById(R.id.number);
        photo = findViewById(R.id.DogPhoto);
        edit = findViewById(R.id.edit);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            value = extras.getString("key");
        }
        db = FirebaseFirestore.getInstance();
        DocumentReference docRef = db.collection("Dogs").document(value);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Map<String,Object> dogData = document.getData();
                        dogName.setText(Objects.requireNonNull(dogData.get("Name")).toString());
                        BD.setText(Objects.requireNonNull(dogData.get("Birthday")).toString());
                        breed.setText(Objects.requireNonNull(dogData.get("Breed")).toString());
                        color.setText(Objects.requireNonNull(dogData.get("Color")).toString());
                        gender.setText(Objects.requireNonNull(dogData.get("dogGender")).toString());
                        ownerName.setText(Objects.requireNonNull(dogData.get("owner_name")).toString());
                        ownerCellPhone.setText(Objects.requireNonNull(dogData.get("owner_cellPhone")).toString());
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(value+".jpeg");
                       storageReference.getBytes(1024*1024).addOnCompleteListener(new OnCompleteListener<byte[]>() {
                           @Override
                           public void onComplete(@NonNull Task<byte[]> task) {
                               Bitmap bitmap = BitmapFactory.decodeByteArray(task.getResult(),0, Objects.requireNonNull(task.getResult()).length);
                               photo.setImageBitmap(bitmap);
                           }
                       });
                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewDogData.this,SignUp.class);
                intent.putExtra("key",value);
                intent.putExtra("view",1);
                startActivity(intent);
            }
        });
    }
}