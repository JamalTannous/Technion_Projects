package com.example.remotedogchipreader;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class signUpUser extends AppCompatActivity {

    EditText etEmail, etPassword, readerID;
    Button register;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_user);
        etEmail = findViewById(R.id.enterMail);
        etPassword = findViewById(R.id.enterPassword);
        readerID = findViewById(R.id.ChipReaderID);
        register = findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean canRegister = checkDataEntered();
                if(canRegister){
                    String email = etEmail.getText().toString();
                    String password = etPassword.getText().toString();
                    String reader = readerID.getText().toString();
                    DocumentReference docRef = db.collection("Users").document(email);
                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    Toast.makeText(signUpUser.this,"Account already exist",Toast.LENGTH_SHORT).show();
                                } else {
                                    Map<String,String> map = new HashMap<>();
                                    map.put("email",email);
                                    map.put("password",password);
                                    map.put("ChipReaderID",reader);
                                    db.collection("Users").document(email).set(map);
                                    Intent intent = new Intent(signUpUser.this,LoginActivity.class);
                                    startActivity(intent);
                                }
                            } else {
                                Log.d(TAG, "get failed with ", task.getException());
                            }
                        }
                    });
                }
            }
        });
    }
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    Boolean checkDataEntered() {
        Boolean canRegister = true;
        if (isEmail(etEmail) == false) {
            etEmail.setError("Enter valid email!");
            canRegister = false;
        }

        if (isEmpty(etPassword)) {
            etPassword.setError("You must enter Password to register!");
            canRegister = false;
        }

        if (isEmpty(readerID)) {
            readerID.setError("Chip reader ID is required!");
            canRegister = false;
        }
        return canRegister;
    }
}



